package com.example.restaurants;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater= getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.ArabicBeef :
            Toast.makeText(this,"Great Choice", Toast.LENGTH_SHORT).show();
            return true;
            case R.id.ArabicBef:
                Toast.makeText(this,"Great Choice", Toast.LENGTH_SHORT).show();
            case R.id.shaima:
                Toast.makeText(this,"Selected", Toast.LENGTH_SHORT).show();
            case R.id.shaima1:
                Toast.makeText(this,"Great Choice", Toast.LENGTH_SHORT).show();
            case R.id.shaima2:
                Toast.makeText(this,"Great Choice", Toast.LENGTH_SHORT).show();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void Click(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("CHOOSE!");
        builder.setMessage("Do you agree that or burger THE BEST burger in the town?");
        builder.setPositiveButton("of Course!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(MainActivity.this,"WE LOVE YOU!",Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("YESSSS!!!!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(MainActivity.this,"THANK YOU!",Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNeutralButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(MainActivity.this,"CANCEL",Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}